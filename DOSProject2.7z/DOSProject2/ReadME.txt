To run the code execute following commands on a windows system
#gossip
mix run 100 3Dtorus gossip 
 
Here
100- Number of nodes
3Dtorus- Topology
gossip- Algorithm

#push-sum
mix run 100 3Dtorus push-sum

Code words for different topologies
"full"-> Full Network 
"rand2D"->Random 2D
"line"->Line 
"honeycomb"->HoneyComb 
"honeycombR"->Random HoneyComb
"3Dtorus"->3D Torus Topology 
